<?php
/**
 * =====================================================================
 * INS3064 - Multimedia Design and Web Development
 * Homework 10: PHP with MySQL — Contact Manager
 * Student Name : Hoang Hoa Binh
 * Student ID   : 23071307
 * File         : edit.php
 * Description  : Form & logic to update an existing contact with PDO
 * =====================================================================
 */

require_once __DIR__ . '/config.php';

$pageTitle = 'Edit Contact';

// 1. Validate & get contact ID from query string or POST
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
}

// Check if ID is missing or invalid
if (!$id) {
    require_once __DIR__ . '/header.php';
    ?>
    <div class="card not-found-card">
        <div class="empty-icon">⚠️</div>
        <h2>Invalid Request</h2>
        <p>No valid contact ID was provided in the request.</p>
        <a href="index.php" class="btn btn-primary">Return to Contact List</a>
    </div>
    <?php
    require_once __DIR__ . '/footer.php';
    exit;
}

// 2. Fetch existing contact from database
try {
    $stmt = $pdo->prepare("SELECT * FROM contacts WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $contact = $stmt->fetch();

    if (!$contact) {
        require_once __DIR__ . '/header.php';
        ?>
        <div class="card not-found-card">
            <div class="empty-icon">🔍</div>
            <h2>Contact Not Found</h2>
            <p>The contact with ID <strong>#<?= (int)$id ?></strong> does not exist or may have been deleted.</p>
            <a href="index.php" class="btn btn-primary">Return to Contact List</a>
        </div>
        <?php
        require_once __DIR__ . '/footer.php';
        exit;
    }
} catch (PDOException $e) {
    die("Database error: " . htmlspecialchars($e->getMessage()));
}

// 3. Initialize variables for form
$name       = $contact['name'];
$email      = $contact['email'];
$phone      = $contact['phone'] ?? '';
$group_name = $contact['group_name'] ?? 'General';
$notes      = $contact['notes'] ?? '';
$errors     = [];

// 4. Handle POST form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name       = trim($_POST['name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $group_name = trim($_POST['group_name'] ?? 'General');
    $notes      = trim($_POST['notes'] ?? '');

    // Validation
    // Validate Name
    if ($name === '') {
        $errors['name'] = 'Name is required and cannot be empty.';
    } elseif (mb_strlen($name) > 100) {
        $errors['name'] = 'Name cannot exceed 100 characters.';
    }

    // Validate Email
    if ($email === '') {
        $errors['email'] = 'Email is required and cannot be empty.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address (e.g., user@example.com).';
    } elseif (mb_strlen($email) > 150) {
        $errors['email'] = 'Email cannot exceed 150 characters.';
    } else {
        // Check uniqueness excluding current contact
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM contacts WHERE email = :email AND id != :id");
            $stmt->execute(['email' => $email, 'id' => $id]);
            if ($stmt->fetchColumn() > 0) {
                $errors['email'] = 'This email address is already in use by another contact.';
            }
        } catch (PDOException $e) {
            $errors['db'] = 'Database error checking email: ' . $e->getMessage();
        }
    }

    // Validate Phone (optional, max 20 chars)
    if ($phone !== '' && mb_strlen($phone) > 20) {
        $errors['phone'] = 'Phone number cannot exceed 20 characters.';
    }

    // Validate Group
    if (!in_array($group_name, CONTACT_GROUPS, true)) {
        $group_name = 'General';
    }

    // 5. Update contact in database if no errors
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                UPDATE contacts 
                SET name = :name, 
                    email = :email, 
                    phone = :phone, 
                    group_name = :group_name, 
                    notes = :notes 
                WHERE id = :id
            ");

            $stmt->execute([
                'name'       => $name,
                'email'      => $email,
                'phone'      => $phone !== '' ? $phone : null,
                'group_name' => $group_name,
                'notes'      => $notes !== '' ? $notes : null,
                'id'         => $id,
            ]);

            set_flash('success', "Contact \"{$name}\" was successfully updated!");
            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            $errors['db'] = 'Failed to update contact: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/header.php';
?>

<div class="page-header">
    <div class="page-header-text">
        <h1 class="page-title">Edit Contact</h1>
        <p class="page-subtitle">Modifying record for <strong><?= e($contact['name']) ?></strong> (ID: #<?= (int)$id ?>)</p>
    </div>
    <div class="page-header-actions">
        <a href="index.php" class="btn btn-outline">
            <span>← Back to Contact List</span>
        </a>
    </div>
</div>

<div class="card form-card">
    <?php if (!empty($errors['db'])): ?>
        <div class="alert alert-error" role="alert">
            <span class="alert-icon">⚠️</span>
            <span class="alert-text"><?= e($errors['db']) ?></span>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?= (int)$id ?>" novalidate class="contact-form">
        <input type="hidden" name="id" value="<?= (int)$id ?>">

        <!-- Name Field -->
        <div class="form-group <?= isset($errors['name']) ? 'has-error' : '' ?>">
            <label for="name" class="form-label">
                Full Name <span class="required">*</span>
            </label>
            <input 
                type="text" 
                id="name" 
                name="name" 
                class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>" 
                value="<?= e($name) ?>"
                required
                autofocus
            >
            <?php if (isset($errors['name'])): ?>
                <span class="error-feedback"><?= e($errors['name']) ?></span>
            <?php else: ?>
                <small class="form-hint">Enter the contact's full display name.</small>
            <?php endif; ?>
        </div>

        <!-- Email Field -->
        <div class="form-group <?= isset($errors['email']) ? 'has-error' : '' ?>">
            <label for="email" class="form-label">
                Email Address <span class="required">*</span>
            </label>
            <input 
                type="email" 
                id="email" 
                name="email" 
                class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" 
                value="<?= e($email) ?>"
                required
            >
            <?php if (isset($errors['email'])): ?>
                <span class="error-feedback"><?= e($errors['email']) ?></span>
            <?php else: ?>
                <small class="form-hint">Must be unique and in valid email format.</small>
            <?php endif; ?>
        </div>

        <div class="form-row">
            <!-- Phone Field -->
            <div class="form-group col-half <?= isset($errors['phone']) ? 'has-error' : '' ?>">
                <label for="phone" class="form-label">Phone Number</label>
                <input 
                    type="tel" 
                    id="phone" 
                    name="phone" 
                    class="form-control <?= isset($errors['phone']) ? 'is-invalid' : '' ?>" 
                    value="<?= e($phone) ?>"
                >
                <?php if (isset($errors['phone'])): ?>
                    <span class="error-feedback"><?= e($errors['phone']) ?></span>
                <?php else: ?>
                    <small class="form-hint">Optional phone or mobile number.</small>
                <?php endif; ?>
            </div>

            <!-- Group Field -->
            <div class="form-group col-half">
                <label for="group_name" class="form-label">Contact Group</label>
                <select id="group_name" name="group_name" class="form-control">
                    <?php foreach (CONTACT_GROUPS as $grp): ?>
                        <option value="<?= e($grp) ?>" <?= ($group_name === $grp) ? 'selected' : '' ?>>
                            <?= e($grp) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <small class="form-hint">Categorize this contact.</small>
            </div>
        </div>

        <!-- Notes Field -->
        <div class="form-group">
            <label for="notes" class="form-label">Notes & Comments</label>
            <textarea 
                id="notes" 
                name="notes" 
                class="form-control" 
                rows="4"
            ><?= e($notes) ?></textarea>
            <small class="form-hint">Additional context, notes, or details.</small>
        </div>

        <!-- Metadata Info -->
        <div class="record-meta">
            <span>Created: <strong><?= e(date('M d, Y H:i:s', strtotime($contact['created_at']))) ?></strong></span>
            <?php if (!empty($contact['updated_at'])): ?>
                <span>Last Updated: <strong><?= e(date('M d, Y H:i:s', strtotime($contact['updated_at']))) ?></strong></span>
            <?php endif; ?>
        </div>

        <!-- Form Actions -->
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <span>💾 Save Changes</span>
            </button>
            <a href="index.php" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
