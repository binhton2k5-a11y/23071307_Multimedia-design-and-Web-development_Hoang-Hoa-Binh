<?php
/**
 * =====================================================================
 * INS3064 - Multimedia Design and Web Development
 * Homework 10: PHP with MySQL — Contact Manager
 * Student Name : Hoang Hoa Binh
 * Student ID   : 23071307
 * File         : footer.php
 * Description  : Common layout footer
 * =====================================================================
 */
?>
        </div><!-- /.container -->
    </main><!-- /.main-content -->

    <!-- Site Footer -->
    <footer class="footer">
        <div class="container footer-inner">
            <div class="footer-left">
                <strong>INS3064 Multimedia Design and Web Development</strong>
                <p>Session 10 Assignment: Contact Manager with PHP Data Objects (PDO)</p>
            </div>
            <div class="footer-right">
                <p>Designed & Developed by <strong><?= e(STUDENT_NAME) ?></strong> (<?= e(STUDENT_ID) ?>)</p>
                <p class="copyright">&copy; <?= date('Y') ?> VNU International School. All rights reserved.</p>
            </div>
        </div>
    </footer>
</div><!-- /.site-wrapper -->
</body>
</html>
