-- =====================================================================
-- INS3064 - Multimedia Design and Web Development
-- Homework 10: PHP with MySQL — Contact Manager
-- Student Name : Hoang Hoa Binh
-- Student ID   : 23071307
-- File         : setup.sql
-- =====================================================================

-- 1. Create database if it does not already exist
CREATE DATABASE IF NOT EXISTS `contact_manager`
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `contact_manager`;

-- 2. Drop existing contacts table to allow clean rebuilds
DROP TABLE IF EXISTS `contacts`;

-- 3. Create contacts table schema
CREATE TABLE `contacts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) UNIQUE,
    `phone` VARCHAR(20),
    `group_name` VARCHAR(50) DEFAULT 'General',
    `notes` TEXT,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Insert at least 5 sample contacts
INSERT INTO `contacts` (`name`, `email`, `phone`, `group_name`, `notes`) VALUES
('Hoang Hoa Binh', 'binh.hoang23071307@vnu.edu.vn', '0912345678', 'Work', 'Student ID: 23071307 - Project Author & Lead Developer'),
('Nguyen Van An', 'an.nguyen@vnu.edu.vn', '0987654321', 'Friends', 'Study buddy at VNU International School, Web Dev team'),
('Tran Thi Mai', 'mai.tran@gmail.com', '0905123456', 'Family', 'Cousin living in Cau Giay, Hanoi - Weekend gathering'),
('Le Quoc Huy', 'huy.le@techcorp.vn', '0934567890', 'Work', 'Tech lead & mentor for Session 10 database integration'),
('Pham Minh Duc', 'duc.pm@domain.org', '0978112233', 'General', 'Met at Hanoi Web Development meetup 2026'),
('Vu Hong Hanh', 'hanh.vu@creative.io', '0944556677', 'Other', 'UI/UX designer collaborator for multimedia projects');
