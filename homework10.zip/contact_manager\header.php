<?php
/**
 * =====================================================================
 * INS3064 - Multimedia Design and Web Development
 * Homework 10: PHP with MySQL — Contact Manager
 * Student Name : Hoang Hoa Binh
 * Student ID   : 23071307
 * File         : header.php
 * Description  : Common layout header & navigation
 * =====================================================================
 */
if (!defined('APP_NAME')) {
    require_once __DIR__ . '/config.php';
}

$pageTitle = isset($pageTitle) ? $pageTitle . ' · ' . APP_NAME : APP_NAME;
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="site-wrapper">
    <!-- Top Identity Bar -->
    <div class="student-bar">
        <div class="container student-bar-inner">
            <span class="course-tag">INS3064 Web Development · Session 10</span>
            <span class="student-info">
                <strong>Student:</strong> <?= e(STUDENT_NAME) ?> 
                <span class="badge-id">ID: <?= e(STUDENT_ID) ?></span>
            </span>
        </div>
    </div>

    <!-- Main Navigation Bar -->
    <header class="navbar">
        <div class="container navbar-inner">
            <a href="index.php" class="brand">
                <span class="brand-icon">📇</span>
                <span class="brand-text">
                    <strong><?= e(APP_NAME) ?></strong>
                    <small>PDO & MySQL CRUD</small>
                </span>
            </a>
            <nav class="nav-links">
                <a href="index.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) === 'index.php') ? 'active' : '' ?>">
                    <span>📋 All Contacts</span>
                </a>
                <a href="add.php" class="btn btn-primary btn-sm">
                    <span>➕ Add Contact</span>
                </a>
            </nav>
        </div>
    </header>

    <!-- Main Content Area -->
    <main class="main-content">
        <div class="container">
            <!-- Flash Message Banner -->
            <?php if ($flash): ?>
                <div class="alert alert-<?= e($flash['type']) ?>" role="alert">
                    <span class="alert-icon">
                        <?php if ($flash['type'] === 'success'): ?>✅
                        <?php elseif ($flash['type'] === 'error'): ?>⚠️
                        <?php elseif ($flash['type'] === 'warning'): ?>⚡
                        <?php else: ?>ℹ️<?php endif; ?>
                    </span>
                    <span class="alert-text"><?= e($flash['message']) ?></span>
                </div>
            <?php endif; ?>
