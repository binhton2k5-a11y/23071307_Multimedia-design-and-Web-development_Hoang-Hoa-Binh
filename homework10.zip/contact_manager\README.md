# Homework 10: PHP with MySQL — Contact Manager
**Course:** INS3064 · Multimedia Design and Web Development  
**Student Name:** Hoang Hoa Binh  
**Student ID:** 23071307  
**Submission Package:** `homework10.zip`

---

## 📌 Project Overview
A complete, secure, responsive web application for managing contacts built with **PHP 8** and **MySQL (MariaDB)** using **PHP Data Objects (PDO)** with prepared statements.

### Key Features
- **Full CRUD Operations**:
  - **Create**: Add new contacts with server-side validation (unique email, email format, required name, sticky form inputs).
  - **Read**: List contacts with total count badge, zebra striping, contact avatars, and sortable columns (Name, Email, Phone, Group, Created At).
  - **Update**: Edit existing contact details with pre-filled forms and collision-safe email uniqueness validation.
  - **Delete**: Safe delete flow displaying contact preview card on `GET` and executing permanent deletion only on confirmed `POST` request.
- **Search Functionality**:
  - Search by contact name or email using PDO prepared statements (`LIKE :search`).
  - Preserves search term in the search box after query submission.
  - Instant reset/clear button.
- **Session Flash Messages**:
  - Flash feedback alerts (Success, Warning, Error) displayed on top of pages and cleared automatically after display.
- **Security & Best Practices**:
  - 100% PDO prepared statements with named placeholders to prevent SQL Injection.
  - `htmlspecialchars()` on all dynamic outputs to eliminate XSS (Cross-Site Scripting).
  - Proper separation of concerns (`config.php`, `header.php`, `footer.php`, `index.php`, `add.php`, `edit.php`, `delete.php`, `style.css`).

---

## 📁 Directory & File Structure
```text
contact_manager/
├── config.php      # PDO database connection, constants & flash helper functions
├── header.php      # Shared HTML header, student banner & navbar
├── footer.php      # Shared footer & copyright
├── index.php       # Contact listing, search bar, sorting & counter
├── add.php         # Add contact form with sticky input & server validation
├── edit.php        # Edit contact form with pre-filled data & validation
├── delete.php      # Delete confirmation screen (GET) & deletion action (POST)
├── setup.sql       # Database schema and initial sample dataset
├── style.css       # Clean, modern, responsive CSS stylesheet
└── README.md       # Project documentation & assignment guide
```

---

## 🚀 How to Run & Test

### 1. Database Setup
1. Open **XAMPP Control Panel** and start **Apache** and **MySQL**.
2. Open **phpMyAdmin** (`http://localhost/phpmyadmin/`) or terminal:
   ```bash
   C:\xampp\mysql\bin\mysql.exe -u root < setup.sql
   ```
3. The script will create database `contact_manager` and table `contacts` with 6 sample records.

### 2. Access the Application
Place the `contact_manager` folder in your XAMPP web root:
`C:\xampp\htdocs\INS3064\contact_manager\`

Open your browser and navigate to:
```url
http://localhost/INS3064/contact_manager/
```

---

## 🎥 OBS Video Presentation Checklist (1–2 minutes)
When recording your walkthrough video for YouTube (Unlisted):
1. **Introduction**: Say your name (*Hoang Hoa Binh*) and Student ID (*23071307*).
2. **Show the Contact List**: Point out the total contact counter, zebra striping, and group badges.
3. **Live Add**: Click *Add New Contact*, fill in a new record, submit, and show the green flash message.
4. **Live Search**: Enter a query in the search bar and filter contacts.
5. **Live Edit**: Click *Edit*, update the phone number or group, save, and show the updated list.
6. **Live Delete**: Click *Delete*, show the confirmation dialog with contact preview, confirm deletion (POST), and verify removal.
7. **Code Walkthrough**: Briefly show `config.php` (PDO setup) and prepared statements in `add.php`, `edit.php`, `delete.php`.
