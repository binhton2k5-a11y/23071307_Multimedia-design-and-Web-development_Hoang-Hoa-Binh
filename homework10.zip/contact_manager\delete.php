<?php
/**
 * =====================================================================
 * INS3064 - Multimedia Design and Web Development
 * Homework 10: PHP with MySQL — Contact Manager
 * Student Name : Hoang Hoa Binh
 * Student ID   : 23071307
 * File         : delete.php
 * Description  : Safe delete workflow (GET displays confirmation, POST performs deletion)
 * =====================================================================
 */

require_once __DIR__ . '/config.php';

$pageTitle = 'Delete Contact Confirmation';

// 1. Get contact ID
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
}

if (!$id) {
    require_once __DIR__ . '/header.php';
    ?>
    <div class="card not-found-card">
        <div class="empty-icon">⚠️</div>
        <h2>Invalid Request</h2>
        <p>No valid contact ID was provided for deletion.</p>
        <a href="index.php" class="btn btn-primary">Return to Contact List</a>
    </div>
    <?php
    require_once __DIR__ . '/footer.php';
    exit;
}

// 2. Fetch the contact record to ensure it exists
try {
    $stmt = $pdo->prepare("SELECT * FROM contacts WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $contact = $stmt->fetch();

    if (!$contact) {
        require_once __DIR__ . '/header.php';
        ?>
        <div class="card not-found-card">
            <div class="empty-icon">🔍</div>
            <h2>Contact Not Found</h2>
            <p>The contact you are attempting to delete does not exist or has already been removed.</p>
            <a href="index.php" class="btn btn-primary">Return to Contact List</a>
        </div>
        <?php
        require_once __DIR__ . '/footer.php';
        exit;
    }
} catch (PDOException $e) {
    die("Database error: " . htmlspecialchars($e->getMessage()));
}

// 3. Perform Deletion ONLY on POST Request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $pdo->prepare("DELETE FROM contacts WHERE id = :id");
        $stmt->execute(['id' => $id]);

        set_flash('success', "Contact \"{$contact['name']}\" was successfully deleted.");
        header('Location: index.php');
        exit;
    } catch (PDOException $e) {
        set_flash('error', "Could not delete contact: " . $e->getMessage());
        header('Location: index.php');
        exit;
    }
}

// 4. On GET Request: Display Confirmation Dialog
require_once __DIR__ . '/header.php';
?>

<div class="page-header">
    <div class="page-header-text">
        <h1 class="page-title text-danger">Confirm Deletion</h1>
        <p class="page-subtitle">Please verify the contact details below before confirming permanent deletion.</p>
    </div>
    <div class="page-header-actions">
        <a href="index.php" class="btn btn-outline">
            <span>← Cancel & Go Back</span>
        </a>
    </div>
</div>

<div class="card delete-confirmation-card">
    <div class="delete-warning-banner">
        <span class="warning-icon">⚠️</span>
        <div>
            <h3>Are you sure you want to delete this contact?</h3>
            <p>This action is <strong>permanent</strong> and cannot be undone. The contact record will be deleted from the database.</p>
        </div>
    </div>

    <!-- Contact Details Preview -->
    <div class="contact-preview-box">
        <div class="preview-header">
            <div class="avatar-circle avatar-large">
                <?= strtoupper(mb_substr($contact['name'], 0, 1, 'UTF-8')) ?>
            </div>
            <div>
                <h2 class="preview-name"><?= e($contact['name']) ?></h2>
                <span class="badge badge-group-<?= strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $contact['group_name'] ?? 'general')) ?>">
                    <?= e($contact['group_name'] ?: 'General') ?>
                </span>
            </div>
        </div>

        <dl class="preview-details-list">
            <div class="preview-item">
                <dt>Email Address:</dt>
                <dd><?= !empty($contact['email']) ? e($contact['email']) : '<em>(None)</em>' ?></dd>
            </div>
            <div class="preview-item">
                <dt>Phone Number:</dt>
                <dd><?= !empty($contact['phone']) ? e($contact['phone']) : '<em>(None)</em>' ?></dd>
            </div>
            <div class="preview-item">
                <dt>Record Created:</dt>
                <dd><?= e(date('F d, Y \a\t H:i', strtotime($contact['created_at']))) ?></dd>
            </div>
            <?php if (!empty($contact['notes'])): ?>
                <div class="preview-item">
                    <dt>Notes:</dt>
                    <dd class="preview-notes"><?= nl2br(e($contact['notes'])) ?></dd>
                </div>
            <?php endif; ?>
        </dl>
    </div>

    <!-- Confirmation Form (POST method strictly required) -->
    <form method="POST" action="delete.php" class="delete-form">
        <input type="hidden" name="id" value="<?= (int)$contact['id'] ?>">
        
        <div class="delete-actions">
            <button type="submit" class="btn btn-danger btn-lg">
                <span>🗑️ Yes, Delete Contact Permanently</span>
            </button>
            <a href="index.php" class="btn btn-outline btn-lg">
                Cancel
            </a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
