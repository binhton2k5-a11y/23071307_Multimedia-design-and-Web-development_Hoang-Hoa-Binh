<?php
/**
 * =====================================================================
 * INS3064 - Multimedia Design and Web Development
 * Homework 10: PHP with MySQL — Contact Manager
 * Student Name : Hoang Hoa Binh
 * Student ID   : 23071307
 * File         : index.php
 * Description  : Contact list page with search, statistics, and CRUD actions
 * =====================================================================
 */

require_once __DIR__ . '/config.php';

$pageTitle = 'Contacts List';

// 1. Fetch total count of all contacts in database
try {
    $totalCount = (int)$pdo->query("SELECT COUNT(*) FROM contacts")->fetchColumn();
} catch (PDOException $e) {
    die("Query failed: " . htmlspecialchars($e->getMessage()));
}

// 2. Sorting handling (whitelisted columns for security)
$allowedSortColumns = ['name', 'email', 'phone', 'group_name', 'created_at'];
$sortBy = isset($_GET['sort']) && in_array($_GET['sort'], $allowedSortColumns, true) ? $_GET['sort'] : 'created_at';
$order = isset($_GET['order']) && strtolower($_GET['order']) === 'asc' ? 'ASC' : 'DESC';
$nextOrder = ($order === 'ASC') ? 'desc' : 'asc';

// 3. Search handling
$search = trim($_GET['search'] ?? '');

try {
    if ($search !== '') {
        // Prepared statement for search by name or email
        $sql = "SELECT * FROM contacts 
                WHERE name LIKE :search_name OR email LIKE :search_email 
                ORDER BY {$sortBy} {$order}";
        $stmt = $pdo->prepare($sql);
        $searchParam = '%' . $search . '%';
        $stmt->execute([
            'search_name'  => $searchParam,
            'search_email' => $searchParam,
        ]);
        $contacts = $stmt->fetchAll();
    } else {
        // Fetch all contacts
        $sql = "SELECT * FROM contacts ORDER BY {$sortBy} {$order}";
        $stmt = $pdo->query($sql);
        $contacts = $stmt->fetchAll();
    }
} catch (PDOException $e) {
    die("Database query error: " . htmlspecialchars($e->getMessage()));
}

// Helper for sorting link URLs
function sort_url($column, $currentSort, $currentOrder, $search) {
    $order = ($currentSort === $column && $currentOrder === 'ASC') ? 'desc' : 'asc';
    $params = ['sort' => $column, 'order' => $order];
    if ($search !== '') {
        $params['search'] = $search;
    }
    return 'index.php?' . http_build_query($params);
}

// Helper for sort arrow icons
function sort_indicator($column, $currentSort, $currentOrder) {
    if ($currentSort !== $column) {
        return '<span class="sort-icon inactive">↕</span>';
    }
    return $currentOrder === 'ASC' 
        ? '<span class="sort-icon active">↑</span>' 
        : '<span class="sort-icon active">↓</span>';
}

require_once __DIR__ . '/header.php';
?>

<div class="page-header">
    <div class="page-header-text">
        <h1 class="page-title">Contact Directory</h1>
        <p class="page-subtitle">
            Showing <?= count($contacts) ?> of <?= $totalCount ?> total contacts
            <?php if ($search !== ''): ?>
                <span class="search-indicator">matching <strong>"<?= e($search) ?>"</strong></span>
            <?php endif; ?>
        </p>
    </div>
    <div class="page-header-actions">
        <a href="add.php" class="btn btn-primary">
            <span>➕ Add New Contact</span>
        </a>
    </div>
</div>

<!-- Search & Filter Bar -->
<div class="card search-card">
    <form method="GET" action="index.php" class="search-form">
        <div class="search-input-group">
            <span class="search-icon">🔍</span>
            <input 
                type="text" 
                name="search" 
                id="search" 
                placeholder="Search contacts by name or email..." 
                value="<?= e($search) ?>"
                autocomplete="off"
            >
            <?php if ($search !== ''): ?>
                <a href="index.php" class="btn-clear" title="Clear search">✕</a>
            <?php endif; ?>
        </div>
        <input type="hidden" name="sort" value="<?= e($sortBy) ?>">
        <input type="hidden" name="order" value="<?= e(strtolower($order)) ?>">
        <button type="submit" class="btn btn-secondary">Search</button>
        <?php if ($search !== ''): ?>
            <a href="index.php" class="btn btn-outline">Reset</a>
        <?php endif; ?>
    </form>
</div>

<!-- Contacts Table Card -->
<div class="card table-card">
    <?php if (empty($contacts)): ?>
        <div class="empty-state">
            <div class="empty-icon">📭</div>
            <h3>No contacts found</h3>
            <?php if ($search !== ''): ?>
                <p>No contacts matched your search query <strong>"<?= e($search) ?>"</strong>.</p>
                <a href="index.php" class="btn btn-secondary">Clear Search Filter</a>
            <?php else: ?>
                <p>Your contact list is currently empty. Start by adding your first contact!</p>
                <a href="add.php" class="btn btn-primary">Add Contact Now</a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="contacts-table">
                <thead>
                    <tr>
                        <th class="col-name">
                            <a href="<?= e(sort_url('name', $sortBy, $order, $search)) ?>" class="sort-link">
                                Name <?= sort_indicator('name', $sortBy, $order) ?>
                            </a>
                        </th>
                        <th class="col-email">
                            <a href="<?= e(sort_url('email', $sortBy, $order, $search)) ?>" class="sort-link">
                                Email <?= sort_indicator('email', $sortBy, $order) ?>
                            </a>
                        </th>
                        <th class="col-phone">
                            <a href="<?= e(sort_url('phone', $sortBy, $order, $search)) ?>" class="sort-link">
                                Phone <?= sort_indicator('phone', $sortBy, $order) ?>
                            </a>
                        </th>
                        <th class="col-group">
                            <a href="<?= e(sort_url('group_name', $sortBy, $order, $search)) ?>" class="sort-link">
                                Group <?= sort_indicator('group_name', $sortBy, $order) ?>
                            </a>
                        </th>
                        <th class="col-created">
                            <a href="<?= e(sort_url('created_at', $sortBy, $order, $search)) ?>" class="sort-link">
                                Created At <?= sort_indicator('created_at', $sortBy, $order) ?>
                            </a>
                        </th>
                        <th class="col-actions">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($contacts as $c): ?>
                        <tr>
                            <td class="cell-name">
                                <div class="avatar-cell">
                                    <span class="avatar-circle">
                                        <?= strtoupper(mb_substr($c['name'], 0, 1, 'UTF-8')) ?>
                                    </span>
                                    <div class="name-notes">
                                        <strong><?= e($c['name']) ?></strong>
                                        <?php if (!empty($c['notes'])): ?>
                                            <span class="cell-notes" title="<?= e($c['notes']) ?>">
                                                <?= e(mb_strimwidth($c['notes'], 0, 45, '...')) ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="cell-email">
                                <?php if (!empty($c['email'])): ?>
                                    <a href="mailto:<?= e($c['email']) ?>" class="email-link">
                                        <?= e($c['email']) ?>
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="cell-phone">
                                <?php if (!empty($c['phone'])): ?>
                                    <a href="tel:<?= e($c['phone']) ?>" class="phone-link">
                                        <?= e($c['phone']) ?>
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="cell-group">
                                <?php 
                                $groupClass = 'badge-group-' . strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $c['group_name'] ?? 'general'));
                                ?>
                                <span class="badge <?= e($groupClass) ?>">
                                    <?= e($c['group_name'] ?: 'General') ?>
                                </span>
                            </td>
                            <td class="cell-date">
                                <?= e(date('M d, Y H:i', strtotime($c['created_at']))) ?>
                            </td>
                            <td class="cell-actions">
                                <a href="edit.php?id=<?= (int)$c['id'] ?>" class="btn-action btn-action-edit" title="Edit Contact">
                                    ✏️ Edit
                                </a>
                                <a href="delete.php?id=<?= (int)$c['id'] ?>" class="btn-action btn-action-delete" title="Delete Contact">
                                    🗑️ Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="table-footer">
            <span>Showing all <?= count($contacts) ?> record(s)</span>
            <span>Tip: Click column headers to sort</span>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
