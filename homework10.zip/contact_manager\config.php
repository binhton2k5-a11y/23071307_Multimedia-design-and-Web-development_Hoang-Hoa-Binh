<?php
/**
 * =====================================================================
 * INS3064 - Multimedia Design and Web Development
 * Homework 10: PHP with MySQL — Contact Manager
 * Student Name : Hoang Hoa Binh
 * Student ID   : 23071307
 * File         : config.php
 * Description  : Database configuration & PDO connection setup
 * =====================================================================
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Database Connection Constants
define('DB_HOST', 'localhost');
define('DB_NAME', 'contact_manager');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// 2. Student & App Constants
define('STUDENT_NAME', 'Hoang Hoa Binh');
define('STUDENT_ID', '23071307');
define('APP_NAME', 'Contact Manager');
define('APP_SUBTITLE', 'INS3064 · Multimedia Design & Web Development');

// Contact Groups List
const CONTACT_GROUPS = ['General', 'Family', 'Friends', 'Work', 'Other'];

// 3. Establish PDO Connection
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    die("
    <div style='font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif; max-width: 650px; margin: 40px auto; padding: 24px; border: 1px solid #f87171; background: #fef2f2; border-radius: 12px; color: #991b1b;'>
        <h2 style='margin-top: 0;'>⚠️ Database Connection Failed</h2>
        <p>Could not connect to database <code>" . DB_NAME . "</code> on <code>" . DB_HOST . "</code>.</p>
        <p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>
        <hr style='border: none; border-top: 1px solid #fca5a5; margin: 16px 0;'>
        <p><strong>Troubleshooting checklist:</strong></p>
        <ol style='padding-left: 20px;'>
            <li>Ensure MySQL / MariaDB service is running in XAMPP Control Panel.</li>
            <li>Run <code>setup.sql</code> in phpMyAdmin or via command line to create the database and table.</li>
            <li>Verify database credentials in <code>config.php</code>.</li>
        </ol>
    </div>
    ");
}

/**
 * Escape HTML special characters to prevent XSS (Cross-Site Scripting)
 *
 * @param mixed $data
 * @return string
 */
function e($data) {
    return htmlspecialchars((string)($data ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Set a session flash message
 *
 * @param string $type ('success' | 'error' | 'warning' | 'info')
 * @param string $message
 */
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type'    => $type,
        'message' => $message,
    ];
}

/**
 * Get and clear flash message
 *
 * @return array|null [ 'type' => ..., 'message' => ... ]
 */
function get_flash() {
    // Standard structured flash
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }

    // Fallback support for $_SESSION['message'] & $_SESSION['message_type']
    if (isset($_SESSION['message'])) {
        $flash = [
            'type'    => $_SESSION['message_type'] ?? 'success',
            'message' => $_SESSION['message'],
        ];
        unset($_SESSION['message'], $_SESSION['message_type']);
        return $flash;
    }

    return null;
}
