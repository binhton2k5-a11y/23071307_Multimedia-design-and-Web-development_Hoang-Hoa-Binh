<?php
/**
 * =====================================================================
 * INS3064 - Multimedia Design and Web Development
 * Homework 10: PHP with MySQL — Contact Manager
 * Student Name : Hoang Hoa Binh
 * Student ID   : 23071307
 * File         : add.php
 * Description  : Form & logic to create a new contact with PDO & validation
 * =====================================================================
 */

require_once __DIR__ . '/config.php';

$pageTitle = 'Add New Contact';

// Form input variables (for sticky form)
$name = '';
$email = '';
$phone = '';
$group_name = 'General';
$notes = '';
$errors = [];

// Handle POST request (form submission)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Sanitize & retrieve inputs
    $name       = trim($_POST['name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $group_name = trim($_POST['group_name'] ?? 'General');
    $notes      = trim($_POST['notes'] ?? '');

    // 2. Server-side Validation
    // Validate Name
    if ($name === '') {
        $errors['name'] = 'Name is required and cannot be empty.';
    } elseif (mb_strlen($name) > 100) {
        $errors['name'] = 'Name cannot exceed 100 characters.';
    }

    // Validate Email
    if ($email === '') {
        $errors['email'] = 'Email is required and cannot be empty.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address (e.g., user@example.com).';
    } elseif (mb_strlen($email) > 150) {
        $errors['email'] = 'Email cannot exceed 150 characters.';
    } else {
        // Check uniqueness in database using PDO prepared statement
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM contacts WHERE email = :email");
            $stmt->execute(['email' => $email]);
            if ($stmt->fetchColumn() > 0) {
                $errors['email'] = 'This email address is already registered to another contact.';
            }
        } catch (PDOException $e) {
            $errors['db'] = 'Database error checking email: ' . $e->getMessage();
        }
    }

    // Validate Phone (optional, max 20 chars)
    if ($phone !== '' && mb_strlen($phone) > 20) {
        $errors['phone'] = 'Phone number cannot exceed 20 characters.';
    }

    // Validate Group (must be in allowed list)
    if (!in_array($group_name, CONTACT_GROUPS, true)) {
        $group_name = 'General';
    }

    // 3. Insert into database if no errors
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO contacts (name, email, phone, group_name, notes) 
                VALUES (:name, :email, :phone, :group_name, :notes)
            ");
            
            $stmt->execute([
                'name'       => $name,
                'email'      => $email,
                'phone'      => $phone !== '' ? $phone : null,
                'group_name' => $group_name,
                'notes'      => $notes !== '' ? $notes : null,
            ]);

            // Set success flash message and redirect
            set_flash('success', "Contact \"{$name}\" was successfully created!");
            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            $errors['db'] = 'Failed to insert contact: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/header.php';
?>

<div class="page-header">
    <div class="page-header-text">
        <h1 class="page-title">Add New Contact</h1>
        <p class="page-subtitle">Fill in the contact information below. Name and Email are required.</p>
    </div>
    <div class="page-header-actions">
        <a href="index.php" class="btn btn-outline">
            <span>← Back to Contact List</span>
        </a>
    </div>
</div>

<div class="card form-card">
    <?php if (!empty($errors['db'])): ?>
        <div class="alert alert-error" role="alert">
            <span class="alert-icon">⚠️</span>
            <span class="alert-text"><?= e($errors['db']) ?></span>
        </div>
    <?php endif; ?>

    <form method="POST" action="add.php" novalidate class="contact-form">
        <!-- Name Field -->
        <div class="form-group <?= isset($errors['name']) ? 'has-error' : '' ?>">
            <label for="name" class="form-label">
                Full Name <span class="required">*</span>
            </label>
            <input 
                type="text" 
                id="name" 
                name="name" 
                class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>" 
                placeholder="e.g. Hoang Hoa Binh"
                value="<?= e($name) ?>"
                required
                autofocus
            >
            <?php if (isset($errors['name'])): ?>
                <span class="error-feedback"><?= e($errors['name']) ?></span>
            <?php else: ?>
                <small class="form-hint">Enter the contact's full display name.</small>
            <?php endif; ?>
        </div>

        <!-- Email Field -->
        <div class="form-group <?= isset($errors['email']) ? 'has-error' : '' ?>">
            <label for="email" class="form-label">
                Email Address <span class="required">*</span>
            </label>
            <input 
                type="email" 
                id="email" 
                name="email" 
                class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" 
                placeholder="e.g. binh.hoang23071307@vnu.edu.vn"
                value="<?= e($email) ?>"
                required
            >
            <?php if (isset($errors['email'])): ?>
                <span class="error-feedback"><?= e($errors['email']) ?></span>
            <?php else: ?>
                <small class="form-hint">Must be unique and in valid email format.</small>
            <?php endif; ?>
        </div>

        <div class="form-row">
            <!-- Phone Field -->
            <div class="form-group col-half <?= isset($errors['phone']) ? 'has-error' : '' ?>">
                <label for="phone" class="form-label">Phone Number</label>
                <input 
                    type="tel" 
                    id="phone" 
                    name="phone" 
                    class="form-control <?= isset($errors['phone']) ? 'is-invalid' : '' ?>" 
                    placeholder="e.g. 0912345678"
                    value="<?= e($phone) ?>"
                >
                <?php if (isset($errors['phone'])): ?>
                    <span class="error-feedback"><?= e($errors['phone']) ?></span>
                <?php else: ?>
                    <small class="form-hint">Optional phone or mobile number.</small>
                <?php endif; ?>
            </div>

            <!-- Group Field -->
            <div class="form-group col-half">
                <label for="group_name" class="form-label">Contact Group</label>
                <select id="group_name" name="group_name" class="form-control">
                    <?php foreach (CONTACT_GROUPS as $grp): ?>
                        <option value="<?= e($grp) ?>" <?= ($group_name === $grp) ? 'selected' : '' ?>>
                            <?= e($grp) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <small class="form-hint">Categorize this contact.</small>
            </div>
        </div>

        <!-- Notes Field -->
        <div class="form-group">
            <label for="notes" class="form-label">Notes & Comments</label>
            <textarea 
                id="notes" 
                name="notes" 
                class="form-control" 
                rows="4" 
                placeholder="Additional notes, address, or relationship details..."
            ><?= e($notes) ?></textarea>
            <small class="form-hint">Optional descriptive notes.</small>
        </div>

        <!-- Form Actions -->
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <span>💾 Save Contact</span>
            </button>
            <a href="index.php" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
